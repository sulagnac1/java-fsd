package demo;

public class Division {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b= 5, c= 5, r;
		try {
			r = a / (b - c);
			System.out.println("result" + r);
		}
		catch (Exception e) {
			System.out.println("exception caught");
		}

	}

}
