package demo;

public class Myexception {
	public static void main(String[]args) {
		try {
			int d = 100/0;
		}
		catch(ArithmeticException e) {
		System.out.println("exception handeling");
	    }
	finally {
		System.out.println("final handeling");
	}
}
}