package demo;
import java.io.IOException;

public class Throwsexcep {
	static void fun() throws IOException
	{
		System.out.println("inside");
		throw new IOException("demo");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Throwsexcep m = new Throwsexcep();
			m.fun();
		}
		catch(Exception e) {
			System.out.println("main");
		}
		finally {
			System.out.println("final block");
		}

	}

}
