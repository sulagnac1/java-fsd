package demo;

public class Multi1 implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multi1 m = new Multi1();
		Thread t = new Thread(m);
		t.start();
		System.out.println(t.getName());
	}
	public void run() {
		System.out.println("thread is running");
	}

	}


