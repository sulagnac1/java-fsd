package demo;

abstract class Car1 {
	private String name;
	abstract void start();
	abstract void end();
	public Car1(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}	
}
class Suzuki extends Car1{
	public Suzuki(String name) {
		super(name);
	}
	public void start() {
		System.out.println("start Suzuki");
	}
	public void end() {
		System.out.println("end Suzuki");
	}
	@Override
	public String toString() {
		return "car model:" + getName();
	}
}
class Bmw extends Car1{
	public Bmw(String name) {
		super(name);
	}
	public void start() {
		System.out.println("start Bmw");
	}
	public void end() {
		System.out.println("end Bmw");
	}
	@Override
	public String toString() {
		return "car model:" + getName();
	}
}
class Parent{
	public void display()
	{
		System.out.println("display with no arguments");
	}
	public void display(String msg) {
		System.out.println("message" +msg);
	}
}
class Concepts extends Parent{
	public void display() {
		System.out.println("display child with no arguments");
		super.display();
	}
	public void display(String msg) {
		super.display(msg);
		System.out.println("child message:" +msg);
	}
	public static void main(String[]args) {
		Concepts obj =new Concepts();
		obj.display();
		obj.display("hello world");
		Suzuki s = new Suzuki("suzuki xl6");
		Bmw b = new Bmw(" bmw 3 series");
		s.start();
		s.end();
		System.out.println(s+"\n");
		
		b.start();
		b.end();
		System.out.println(b+"\n");
	}
}
