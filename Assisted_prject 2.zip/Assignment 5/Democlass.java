package demo;
interface Diamond1 {
	 public default void display()
	{
		System.out.println("diamond1 invoked");
	}
}
interface Diamond2{
	public default void display() {
		System.out.println("daimond2 invoked");
	}
}
class Democlass implements Diamond1,Diamond2{
	public void display() {
		Diamond1.super.display();
		Diamond2.super.display();
	}
	public static void main(String[]args) {
		Democlass obj = new Democlass();
		obj.display();
	}
	
}



