package demo;
import java.io.File;
import java.io.IOException;

public class Createfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File myObj = new File("C://Users//KIIT//Desktop//Assignment 5//filename.txt");
			if(myObj.createNewFile()) {
			System.out.println("file created: "+myObj.getName());
			}
			else {
				System.out.println("file already exits");
			}
		}
		catch(IOException e) {
			System.out.println("an error occurred");
			e.printStackTrace();
		}

	}
}
	
