package demo;
import java.io.File;

public class Deletefile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myObj = new File("C://Users//KIIT//Desktop//Assignment 5//filename.txt");
		if(myObj.delete()) {
			System.out.println("deleted the file: " +myObj.getName());
		}
		else {
			System.out.println("failed to delete the file");
		}

	}

}
