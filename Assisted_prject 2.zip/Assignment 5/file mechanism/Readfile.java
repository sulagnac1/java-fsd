package demo;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class Readfile {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File myObj = new File("C://Users//KIIT//Desktop//Assignment 5//filename.txt");
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNext()) {
				String data = myReader.nextLine();
				System.out.println(data);
			}
			myReader.close();
		}
		catch(IOException e) {
			System.out.println("An error occured");
			e.printStackTrace();
		}

	}

}
