package demo;

public class Demostrate {
	private static Object LOCK = new Object();

	public static void main(String[] args) 
		throws InterruptedException{
		        Thread.sleep(1000);
		        System.out.println("thread '" + Thread.currentThread().getName() + " ' is sleeping");
		        synchronized(LOCK) {
		        	LOCK.wait(1000);
		        	System.out.println("object ' " + LOCK + " ' waiting for 1sec");
		        }
		
			
		}

	}


