package com.ecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration_Automation {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		google_login(driver);

	}
	
	public static void google_login (WebDriver driver) throws InterruptedException {
		
		String baseURL = "https://accounts.google.com/signup/v2/createaccount?flowEntry=SignUp";
		
		driver.get(baseURL);
		
		WebElement firstNameTF = driver.findElement(By.id("firstName"));
		firstNameTF.sendKeys("Sulagna");
		Thread.sleep(3000);
		
		WebElement lastNameTF = driver.findElement(By.id("lastName"));
		lastNameTF.sendKeys("Chatterjee");
		Thread.sleep(3000);
		
		WebElement nextButton = driver.findElement(By.className("VfPpkd-vQzf8d"));
		nextButton.click();
		
		String fullXPathOfDayDropDown = 
				"/html/body/div[1]/div[1]/div[1]/div[2]/div/div[2]/div/div/div[1]/form/div[1]/div[5]/div[2]/span/span/select[1]";
		WebElement dayDropDown = driver.findElement(By.xpath(fullXPathOfDayDropDown));
		
		Select select1 = new Select(dayDropDown);
		select1.selectByVisibleText("27");
		
		String xPathOfMonth = "/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div[2]/div/div/div[2]/select";
		WebElement monthSelectElement = driver.findElement(By.xpath(xPathOfMonth));
		System.out.println("monthSelectElement details "+monthSelectElement);	
		
		Select select2 = new Select(monthSelectElement);
		select2.selectByValue("7");	
		
		String xPathOfYear = "/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div[2]/div/div/div[2]/select";
		WebElement yearSelectElement = driver.findElement(By.xpath(xPathOfYear));
		System.out.println("monthSelectElement details "+yearSelectElement);	
		
		Select select3 = new Select(yearSelectElement);
		select3.selectByValue("1999");
		
		WebElement nextButton2 = driver.findElement(By.className("VfPpkd-vQzf8d"));
		nextButton2.click();
		
		
		Thread.sleep(10000);
		
		driver.close();
		
	}

}
