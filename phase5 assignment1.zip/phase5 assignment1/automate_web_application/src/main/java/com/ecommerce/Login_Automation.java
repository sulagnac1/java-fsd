package com.ecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Automation {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		facebook_login(driver);
		
	}
	
	public static void facebook_login(WebDriver driver) {
		
		driver.get("https://www.facebook.com/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjY0MzY3NDQ2LCJjYWxsc2l0ZV9pZCI6MjY5NTQ4NDUzMDcyMDk1MX0%3D");
        
        driver.manage().window().maximize();
        
        driver.findElement(By.id("email"))
        .sendKeys("sulagna@gmail.com");
        
        driver.findElement(By.id("pass"))
        .sendKeys("sulagna@1234");
        
        driver.findElement(By.id("loginbutton"))
        .click();
		
	}

}
