package demo;

public class Smallestelement {
	// method for sorting the array  
		public void sortArr(int arr[])  {
				int size = arr.length;  
				for(int i = 0; i < size; i++)  
				{  
					int temp = i;  
					for(int j = i + 1; j < size; j++)  
					{  
						if(arr[temp] > arr[j])  
						{  
							temp = j;  
						}  
					}  
					if(temp != i)  
					{  
						int t = arr[i];  
						arr[i] = arr[temp];  
						arr[temp] = t;   
					}  
				}  
		}  
	  
		// find the  smallest element of the array  
	public int findSmallestelement(int arr[], int k)  
	{  
		sortArr(arr);  
	  
		// as an array is always a zero indexing  
		// therefore, the  smallest element lies  
		// at the k - 1 index  
		return arr[k - 1];  
	}  
	  
	  
	// main method  


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Smallestelement obj = new Smallestelement();  
		  
		int arr[] = {56, 34, 7, 9, 0, 48, 41, 8};  
	  
		int size = arr.length;  
		int k = 3;  
	  
		System.out.println("For the array: ");  
		for(int i = 0; i < size; i++)  
		{  
			System.out.print(arr[i] + " ");  
		}  
	  
		int ele = obj.findSmallestelement(arr, k);  
	  
		System.out.println();  
		System.out.println("The " + k + "rd smallest element of the array is: " + ele);  
	  
		System.out.println("\n");  
	  
		int arr1[] = {70, 67, 80, 9, 13, 41, 12, 30, 87, 90};  
	  
		size = arr1.length;  
		k = 4;  
	  
		System.out.println("For the array: ");  
		for(int i = 0; i < size; i++)  
		{  
			System.out.print(arr1[i] + " ");  
		}  
	  
		ele = obj.findSmallestelement(arr1, k);  
	  
		System.out.println();  
		System.out.println("The " + k + "th smallest element of the array is: " + ele);
}
}
	


  
		