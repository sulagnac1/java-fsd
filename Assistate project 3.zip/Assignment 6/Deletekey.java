package demo;

public class Deletekey {
	class Node{
		int d;
		Node next;
		public Node(int d) {
			this.d=d;
			this.next=null;
		}
	}
	public Node head= null;
	public Node tail = null;
	public void addNode(int d) {
		Node newNode= new Node(d);
		if(head==null) {
			head =newNode;
			tail =newNode;
		}
		else {
			tail.next=newNode;
			tail =newNode;
		}
	}
	public void deleteFromStart() {
		if(head==null) {
			System.out.println("list is empty");
			return;
		}
		else {
			if(head !=tail) {
				head =head.next;
			}
			else {
				head = tail = null;
			}
		}
	}
	public void display() {
		Node c = head;
		if(head==null) {
			System.out.println("list is empty");
			return;
		}
		while(c!=null) {
			System.out.println(c.d+" ");
			c = c.next;
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deletekey sl=new Deletekey();
		sl.addNode(1);
		sl.addNode(2);
		sl.addNode(3);
		sl.addNode(4);
		System.out.println("original list");
		sl.display();
		while(sl.head!= null) {
			sl.deleteFromStart();
			System.out.println("updated list");
			sl.display();
		}
	}
}
