package demo;

public class Array_implementation {
	public static void main (String[] args) {
		
		int[] array = {10,20,30,40,50,60,70,80,90,100};
		int array_length = array.length;
		System.out.println("number of element: " + array_length);
		
		for(int i=0;i<array.length;i++) {
			System.out.println("Array elements  :" +array[i]);
		}

		int result=0;
		for(int i=0;i<array.length;i++) {
			result += array[i]; 
		}
		System.out.println("Sum  " +result);
		
		double average = ((double ) result)/(double) array_length;
		System.out.println("Average = " +average);
	}
}


