package demo;

public class Constructor1 {
	private String name;
	private Constructor1() {
		System.out.println("constructor invoked");
		name = "Sulagna";
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor1 a = new Constructor1();
		System.out.println("name: " +a.name);
		

	}


}
