package flipkart;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class FlipkartTest {
@Test
public void FlipkartTesting() throws InterruptedException 
{
 System.out.println("Navigate to the home page");
 wd.get("https://www.flipkart.com/");
 
 wd.manage().window().maximize();
 
 System.out.println("Navigation done on Chrome\n");
 System.out.println("Page load time");
 
long start = System.currentTimeMillis();
long finish = System.currentTimeMillis();
long totalTime = finish - start;
 System.out.println("Total Time for page load -"+totalTime+"\n");
 
 System.out.println("Searching for an item");
 
 WebElement textFieldRef = wd.findElement(By.name("q"));
 textFieldRef.sendKeys("Iphone 13");
 
 
wd.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
 
 WebElement buttonRef = 
wd.findElement(By.className("L0Z3Pu"));
 buttonRef.click();
 
 System.out.println("Search done successfully\n");
/* System.out.println("Checking whether images are loaded");
 
 
 List<WebElement> image1 = wd.findElements(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div/div/img"));
 Boolean imageLoaded1 = (Boolean)
 ((JavascriptExecutor)wd).executeScript("return arguments[0].complete && "+ "typeof arguments[0].naturalWidth != \"undefined\" && "+"arguments[0].naturalWidth > 0", image1);
 
 if (!imageLoaded1)
 {
 System.out.println("Image is not present");
 }
 else
 {
 System.out.println("Image is present");
 }*/
 System.out.println("Checking whether images are loaded");

//Find the image element
List<WebElement> image1 = wd.findElements(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div/div/img"));

if (!image1.isEmpty()) {
  // Execute JavaScript to check image loading status
  Boolean imageLoaded1 = (Boolean) ((JavascriptExecutor) wd).executeScript(
          "return arguments[0].complete && " +
          "typeof arguments[0].naturalWidth !== 'undefined' && " +
          "arguments[0].naturalWidth > 0", image1.get(0));

  // Check the result
  if (imageLoaded1 != null && imageLoaded1.booleanValue()) {
      System.out.println("Image is present and fully loaded.");
  } else {
      System.out.println("Image is not present or not fully loaded.");
  }
} else {
  System.out.println("Image element not found.");
}

 
 System.out.println("The images are loaded and visible till the screen height only\n"); 
 JavascriptExecutor js = (JavascriptExecutor)wd;
 
 try {
 long temp = 0;
 while (true) {
 ((JavascriptExecutor) 
wd).executeScript("window.scrollTo(0,document.body.scrollHeight);");
 Thread.sleep(2500);
 long Start = (Long) 
((JavascriptExecutor)wd).executeScript("return document.body.scrollHeight");
 if (Start == temp) 
 {
 break;
 }
 temp = Start;
 }
 System.out.println("Scrolling completed and works successfully");
 System.out.println("Images loaded successfully\n");
 } catch (Exception e) {
 e.printStackTrace();
 }
 
 System.out.println("Navigate to the bottom of the page");
 
js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
 System.out.println("Navigation done successfully\n");
 
 //WebElement imageToClick = wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[5]/div[1]/div[2]/a"));
 
 WebElement imageToClick = wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[25]/div/div/div/a"));
 
//Perform the click action on the link
 imageToClick.click();

 // Add a short delay to give time for the link to be clicked and processed (if needed)
 Thread.sleep(2000);

 System.out.println("image clicked successfully");

 /*System.out.println("Navigate to the bottom of the page");
 
 js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
  System.out.println("Navigation done successfully\n");*/
 
 }
 WebDriver wd;
 @BeforeMethod
 public void beforeMethod() {
 
System.setProperty("webdriver.chrome.driver","C:\\Users\\KIIT\\Desktop\\chromedriver.exe");
 wd=new ChromeDriver();
 }
 
 @AfterMethod
 public void afterMethod() {
 }
}