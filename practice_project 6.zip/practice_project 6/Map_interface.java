package demo;
import java.util.*;


public class Map_interface {
	public static void main(String[] args) {
		// Creating a map
		
		HashMap<String, Integer> map = new HashMap<>();
		
		// Adding element
		
		map.put("Hello !", 1);
		map.put("I", 2);
		map.put("am", 3);
		map.put("Sulagna", 4);
		map.put("Chatterjee", 5);
		
		for(Map.Entry<String, Integer> m: map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}


}
