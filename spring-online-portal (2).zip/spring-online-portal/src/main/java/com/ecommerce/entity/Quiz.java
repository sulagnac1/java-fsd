package com.ecommerce.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="quiztable")
public class Quiz {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ID;
	
	@Column(name="title")
	private String title;
	
	@Column(name="category")
	private String category;
	
	@ManyToMany
	@JoinTable(name="QUIZ_QUESTIONS",
		joinColumns = @JoinColumn(name="QUIZ_ID"),
		inverseJoinColumns = @JoinColumn(name="QUESTION_ID")
			)
	private List<Question> questions = new ArrayList<>();
	public Quiz()
	{
		
	}

	public Quiz(Long iD, String title, String category) {
		super();
		ID = iD;
		this.title = title;
		this.category = category;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public List<Question> getCourses() {
		return questions;
	}
	 public void addQuestion(Question question) {
	        questions.add(question);
	        question.setQuiz(this);
	    }

}
