	package com.ecommerce.controllers;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.validation.BindingResult;
	import org.springframework.validation.annotation.Validated;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PostMapping;
	
	import com.ecommerce.entity.UserEntity;
	import com.ecommerce.repository.UserRepo;
	
	@Controller
	public class UserController {
	
		@Autowired
		UserRepo userRepo;
		
		@GetMapping("/add-user")
		public String showNewUserForm(Model model) {
	
			UserEntity user = new UserEntity();
			model.addAttribute("user", user);
	
			return "signup"; // go to new-product.jsp
		}
		
		@PostMapping("/add-user")
		public String addNewProduct(@ModelAttribute("user") UserEntity user) {
			userRepo.save(user);
	
			return "index"; // go to new-product-added-success.jsp
		}
		
		@GetMapping("/login")
		public String loginForm(Model model) {
	
			UserEntity user = new UserEntity();
			model.addAttribute("user", user);
	
			return "login"; // go to new-product.jsp
		}
		 
		@PostMapping("/login")
		public String login(@ModelAttribute("user") UserEntity user,Model model) {
		    UserEntity existingUser = userRepo.findByUsername(user.getUsername());
	
		    if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
		    	 model.addAttribute("user", existingUser);
		        if (existingUser.getRole().equalsIgnoreCase("admin")) {
		            return "admin-dashboard"; // Redirect to the admin dashboard
		        } else {
		            return "user-dashboard"; // Redirect to the user dashboard
		        }
		    } else {
		        return "error"; // Redirect back to the login form with an error parameter
		    }
			
		}
	}
