package demo;
import java.util.*;

public class Collection1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[] {10, 20, 30, 40};
		Vector<Integer> v = new Vector();
		v.add(1);
		v.add(2);
		System.out.println(arr[0]);
		System.out.println(v.elementAt(0));
		

	}

}
