package cremera_rental;
import java.util.*;
public class Camera {
private static int counter = 0;
    private int Camera_id;
    private String Brand;
    private String Model;
    private double Price_per_day;
    public boolean Status;
    public String Rent;
    Camera(String brand, String model, double rentAmount)
    {
    	this.Camera_id = ++counter;
        this.Brand = brand;
        this.Model = model;
        this.Price_per_day = rentAmount;
        this.Status = false;
        this.Rent="";
    }
    public int getId() {
        return Camera_id;
    }

    public String getBrand() {
        return Brand;
    }

    public String getModel() {
        return Model;
    }

    public double getRentAmount() {
        return Price_per_day;
    }
    public boolean isStatus() {
        return Status;
    }

    public void rent() {
        this.Status = true;
    }
    public String getRent()
    {
    	return this.Rent;
    }
    public void setRent(String Rent)
    {
    	this.Rent=Rent;
    }
    public void returnCamera() {
        this.Status = false;
      
    }

}
