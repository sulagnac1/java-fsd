package cremera_rental;
import java.util.*;

public class Method {

	protected  List<Camera> cameraList1;
    private List<User1> userList;
    public Method() 
    {
        cameraList1 = new ArrayList<>();
        userList = new ArrayList<>();
    }
    public void addBefore()
    {
    	cameraList1.add(new Camera("Samsung", "DS123", 500.0));
    	cameraList1.add(new Camera("Sony", "HD214", 500.0));
    	cameraList1.add(new Camera("Panasonic","XC", 500.0));
    	cameraList1.add(new Camera("Canon","LR",500.0));
    	cameraList1.add(new Camera("Fujitsu","J5",500.0));
    	cameraList1.add(new Camera("Sony","HD226",500.0));
    	cameraList1.add(new Camera("LG","L123",500.0));
    	cameraList1.add(new Camera("Canon","XPL",500.0));
    	cameraList1.add(new Camera("Chroma","CT",500.0));
    	cameraList1.add(new Camera("Canon", "Digital", 123.0));
    	cameraList1.add(new Camera("NIKON", "DSLR - D7500", 500.0));
    	cameraList1.add(new Camera("Sony", "DSLR12", 200.0));
    	cameraList1.add(new Camera("SONY", "SONY1234", 123.0));
    	cameraList1.add(new Camera("Canon", "5050", 2500.0));
    	cameraList1.add(new Camera("nikon", "2030", 500.0));


    	
    	
    }
    public void addCamera(Camera camera)
    {
        cameraList1.add(camera);
        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST");
        return;
    }
    public void addUser(User1 user)
    {
        userList.add(user);
    }
    public void removeCamera(int cameraId) {
        Iterator<Camera> iterator = cameraList1.iterator();
        while (iterator.hasNext()) {
            Camera camera = iterator.next();
            if (camera.getId() == cameraId) {
                iterator.remove();
                System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
                return;
            }
        }
        System.out.println("Camera with ID " + cameraId + " not found in the list.");
    }
    public void displayAvailableCameras() 
    {
    	if (cameraList1.isEmpty()) {
            System.out.println("No cameras are currently available for rent.");
        } 
    	else
    	{
    	    System.out.println("===============================================================");
    		System.out.println("Camera ID    Brand      Model     Price (Per Day)  Status");
    		System.out.println("===============================================================");
    	    for (Camera camera : cameraList1) {
    	        System.out.printf("%-12d %-10s %-10s %-16.2f %s%n",
    	                camera.getId(), camera.getBrand(), camera.getModel(),
    	                camera.getRentAmount(), camera.isStatus() ? "Rented" : "Available");
    	    }
    	    System.out.println("===============================================================");
    	}
       
    }
    public void displayMyCameras(String username)
    {
    	System.out.println("===============================================================");
 		System.out.println("Camera ID    Brand      Model     Price (Per Day)  Status");
    	for(Camera camera : cameraList1)
    	{
    		if(camera.getRent().equals(username))
        	{
    			 System.out.printf("%-12d %-10s %-10s %-16.2f %s%n",
     	                camera.getId(), camera.getBrand(), camera.getModel(),
     	                camera.getRentAmount(), camera.isStatus() ? "Rented" : "Available");
        	}
    	}
    	System.out.println("===============================================================");
    }
    public void rentCamera(User1 user, int cameraId) throws InsufficientBalanceException
    {
        for (Camera camera : cameraList1) {
            if (camera.getId() == cameraId) {
            	if (camera.isStatus()) {
                    System.out.println("Camera is already rented.");
                }
            	else{
            		double rentAmount = camera.getRentAmount();

                    if (user.hasSufficientBalance(rentAmount)) {
                        user.deductBalance(rentAmount);
                        camera.rent();
                        System.out.println("Your transaction for camera - "+camera.getBrand()+" "+camera.getModel()+" with rent INR."+camera.getRentAmount()+" has successfully completed");
                    } 
                    else{
                        //System.out.println("Insufficient wallet amount. Rent not possible.");
                    	throw new InsufficientBalanceException("Insufficient balance in your wallet to rent the camera.");
                    }
            	}
                
                return;
            }
        }
        System.out.println("Invalid camera ID.");
    }
}

