package cremera_rental;

public class User1 {
	private String username;
    private double walletBalance;
	public User1(String username, double walletBalance) {
        this.username = username;
        this.walletBalance = walletBalance;
    }

    public String getUsername() {
        return username;
    }

    public double getWalletBalance() {
        return walletBalance;
    }

    public void deposit(double amount) {
        walletBalance += amount;
        System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE INR " + walletBalance);
    }

    public boolean hasSufficientBalance(double amount) {
        return walletBalance >= amount;
    }

    public void deductBalance(double amount) {
        walletBalance -= amount;
    }


}
