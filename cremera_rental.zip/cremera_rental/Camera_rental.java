package cremera_rental;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Camera_rental extends Method
{
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		Method obj = new Method();
		obj.addBefore();
		 System.out.println("WELCOME TO CAMERA RENTAL APP");
		 System.out.println("PLEASE LOGIN TO CONTINUE");
	     System.out.print("USERNAME -\n ");
	     String username = sc.nextLine();
	     System.out.print("PASSWORD\n ");
	     String password = sc.nextLine();
	     if (username.equals("sulu") && password.equals("1234"))
	     {
	    	 User1 user = new User1(username, 500);
	    	 obj.addUser(user);
	    	 int exit1 = 1;
	    	 while(exit1!=0)
	    	 {
	    		 System.out.println("1. MY CAMERA");
	             System.out.println("2. RENT A CAMERA");
	             System.out.println("3. VIEW ALL CAMERAS");
	             System.out.println("4. MY WALLET");
	             System.out.println("5. EXIT");
	             int choice = sc.nextInt();
	    		 switch(choice)
	    		 {
	    		 	case 1:
	    		 		int exit2=1;
	    		 		while(exit2!=0)
	    		 		{
	    		 			System.out.println("1. ADD");
	                        System.out.println("2. REMOVE");
	                        System.out.println("3. VIEW MY CAMERAS");
	                        System.out.println("4. GO TO PREVIOUS MENU");
	                        int Choice=sc.nextInt();
	    		 			switch(Choice)
	    		 			{
	    		 				case 1:
	    		 					System.out.print("ENTER THE CAMERA BRAND - ");
	    		 					sc.nextLine();
	                                String Brand = sc.nextLine();
	                                System.out.print("ENTER THE MODEL - ");
	                                String Model = sc.nextLine();
	                                System.out.print("ENTER THE PER DAY PRICE (INR) - ");
	                                double Price_per_day = sc.nextDouble();
	                                sc.nextLine(); 
	                                Camera camera = new Camera(Brand, Model,Price_per_day );
	                                obj.addCamera(camera);
	                                camera.setRent(user.getUsername());
	                                break;
	    		 				case 2:
	    		 					obj.displayAvailableCameras();
	    		 					System.out.print("ENTER THE CAMERA ID TO REMOVE ");
	                                int cameraId = sc.nextInt();
	                                sc.nextLine();
	                                obj.removeCamera(cameraId);
	                                break;
	    		 				case 3:
	    		 					System.out.println("YOUR RENTED CAMERAS:");
	    		 					
	    		 					obj.displayMyCameras(user.getUsername());
									break;
	    		 				case 4:exit2=0;
	    		 						break;
	    		 			}
	    		 			
	    		 		}
	    		 		break;
	    		 		case 2:
	    		 			obj.displayAvailableCameras();
                            System.out.print("Enter the camera ID you want to rent: ");
                            int rentCameraId = sc.nextInt();
                            try {
                            	obj.rentCamera(user, rentCameraId);
                            }	
                            catch (InsufficientBalanceException e) {
                            	System.out.println(e.getMessage());
                            }
                            break;
	    		 		case 3:
	    		 			 obj.displayAvailableCameras();
	                         break;
	    		 		case 4:
	    		 			System.out.println("YOUR CURRENT WALLET BALANCE IS INR " + user.getWalletBalance());
	                        try
	                        {
	                        	System.out.print("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET? (1.YES 2.NO) - ");	
	                        	int depositChoice = sc.nextInt();
		                        sc.nextLine(); 
		                        if (depositChoice == 1) {
		                            System.out.print("ENTER THE AMOUNT (INR) - ");
		                            double depositAmount = sc.nextDouble();
		                            user.deposit(depositAmount);
		                            
		                        } else if (depositChoice != 2) {
		                            System.out.println("Invalid choice.");
		                        }

	                        }
	                        catch (InputMismatchException e) {
                            	System.out.println("Exception raised  ");
                            	System.out.println("Please enter 1 which means YES or 2 which means NO.");
                            	sc.nextLine(); 
                            }
	                        
	                        break;
	    		 		case 5:
	    		 			exit1=0;
	    		 			break;
	    		 }
	    	 }
	    	 closeApp();
	     }
	}
	public static void closeApp()
	{
		System.out.println("Closing The Application");
	}
}
