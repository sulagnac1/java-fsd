package demo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Regex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String pattern = "[a-z]+";
		String check = "Regular Expressions";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(check);
		
		while (m.find())
	      	System.out.println( check.substring( m.start(), m.end() ) );

	}

}
