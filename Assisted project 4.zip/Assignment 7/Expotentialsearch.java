package demo;
import java.util.Arrays;

public class Expotentialsearch {
	static int expotentialSearch(int arr[], int n, int a) {
		if(arr[0]==a) {
			return 0;
		}
		int i =1;
		while (i<n &&arr[i]<=a) {
			
				i=i*2;
		}
		return Arrays.binarySearch(arr, i/2, Math.min(i, n-1),a);
		}
	
	public static void main(String[]args) {
		int arr[] = {2, 3,4, 10, 40};
		int a= 10;
		int result= expotentialSearch(arr,arr.length,a);
		System.out.println((result<0)? "not present\n":"present\n"+result);
	}

}
