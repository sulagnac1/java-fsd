package demo;

public class Insertionsort {
	public static void insertionSort(int arr[]) {
		int n =arr.length;
		for(int j =1; j<n;j++) {
			int key= arr[j];
			int i =j-1;
			while((i>-1)&&(arr[i]>key)) {
				arr[i+1]=arr[i];
				i--;
			}
			arr[i+1]=key;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr1[]= {22, 58,11,43, 2, 14, 3, 9};
		System.out.println("before sort");
		for(int i:arr1) {
			System.out.print(i+" ");
		}
		System.out.println();
		insertionSort(arr1);
		System.out.println("after sort");
		for(int i:arr1) {
			System.out.println(i+" ");
		}

	}

}
