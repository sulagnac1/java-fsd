package demo;

public class Linearsearch {
	public static int linearSearch(int[]arr, int key) {
		for (int i=0;i<arr.length;i++) {
			if(arr[i]==key) {
				return i;
				
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {90,70,50,30,20,10};
		int key=30;
		System.out.println(key+"index"+linearSearch(a,key));

	}

}
