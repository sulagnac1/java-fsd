package demo;

public class Binarysearch {
	public static void binarySearch(int arr[], int f, int l,int key) {
		int mid=(f+l)/2;
		while(f<=l) {
			if(arr[mid]<key) {
				f = mid +1;
			}
			else if(arr[mid]==key) {
				System.out.println("index found"+mid);
				break;
			}
			else {
				l = mid -1;
			}
			mid=(f+l)/2;
		}
		if(f>l) {
			System.out.println("index not found");
		}
	}
	public static void main(String [] args) {
		int arr[]= {50,40,30,20,10};
		int key = 30;
		int l=arr.length-1;
		binarySearch(arr, 0,l,key);
	}
}
